# Sequence Diagram generator

This is a great tool that I have adapted from https://github.com/bramp
To use it, simply download this folder and launch use-case.html

You can try it out here http://ngpanwei.com/uc/


